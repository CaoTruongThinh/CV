function tinhtong(a, b) {
  return a + b;
}

let a = 5;
let b = 13;
let c = tinhtong(a, b);
console.log(c);

let array = [1, 2, 3, 4];
let tong = 0;
for (let i = 0; i < array.length; i++) {
  tong += array[i];
}
console.log(tong);
